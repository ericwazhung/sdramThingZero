// Send the numbers 0-9 to this device via RS-232.
// On reception, the heart will blink the requested number of times.
// (0 puts it back into fading-mode)




#include _HEARTBEAT_HEADER_
#include _POLLED_UAR_HEADER_
void main(void)
{

	init_heartBeat();

	puar_init(0);

	while(1)
	{
		puar_update(0);

		if(puar_dataWaiting(0))
		{
			uint8_t byte = puar_getByte(0);

			if((byte >= '0') && (byte <= '9'))
				set_heartBlink(byte-'0');
		}

		heartUpdate();
	}
}

