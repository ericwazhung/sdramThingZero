#ifndef __PINOUT_H__
#define __PINOUT_H__

//This should be moved to the makefile...
//Using the LCDdirect '2-bit' board's pinout, which does NOT use the
//default heart pin.
//#define HEARTBEAT       PB2       //(NOT MISO)
//#define HEARTBEATPIN    PINB
//#define HEARTCONNECTION LED_TIED_HIGH


//Using the programming-header for debugging uart...
//
//
// 1  GND
// 2  V+
// 3  SCK   PA4   Rx0   (puar)
// 4  MOSI  PA6   Tx0   (puat)
// 5  /RST
// 6  MISO  PA5   (NOT Heart)

//_PGM_xxx_yyy_NAME_ is a new method, a/o atmega328p.mk
// Most devices don't yet have it implemented, so must put actual pin/port
// names here (The commented pin/port names are from another device!)
#define Rx0pin    _PGM_SCK_PIN_NAME_ //PA4      //SCK
#define Rx0PORT   _PGM_SCK_PORT_NAME_ //PORTA

#define Tx0pin		_PGM_MOSI_PIN_NAME_ //PA6		//MOSI
#define Tx0PORT	_PGM_MOSI_PORT_NAME_ //PORTA



#endif

