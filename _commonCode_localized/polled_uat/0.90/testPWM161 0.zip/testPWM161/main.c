//Stolen from adc/0.21/testPWM161 (which was nowhere near ADCing at the
//time)

//This is nearly identical to anaButtons/0.50/test/
// but for the tiny861
// Notes are probably not all updated, and probably weren't in "test"...
// (and below is a prime example)



// Prints "Hello World" on boot to the RS-232 Transmitter, then echos
// anything received, therafter.
// Send the numbers 0-9 to this device via RS-232.
// On reception, the heart will blink the requested number of times.
// (0 puts it back into fading-mode)



#include _HEARTBEAT_HEADER_
#include _POLLED_UAT_HEADER_
#include <stdio.h> //necessary for sprintf_P...
						// See notes in the makefile re: AVR_MIN_PRINTF
#include <util/delay.h>

//For large things like this, I prefer to have them located globally (or
//static) in order to show them in the memory-usage when building...
char stringBuffer[80];


int main(void)
{

	init_heartBeat();

	tcnter_init();
	puat_init(0);

	// If you're *only* using the tcnter for puat, it's entirely safe to do
	// something like this... BUT, there are various things which may use
	// tcnter in the background without your realizing (puar, for instance)
	// So don't get in the habit of doing this unless you're really on top
	// of things.

	//(Also, should put this in a PSTR() rather than a RAM-based
	//character array...)
/*
	char hello[] = "Hello World\n\r";
	char* character = hello;

	setHeartRate(16);

	//Nothing can be received during this loop...
	while(*character != '\0')
	{
		puat_sendByte(0, *character);
		character++;
		while(puat_dataWaiting(0))
		{
			tcnter_update();
			puat_update(0);
			heartUpdate();
		}
	}
*/
	puat_sendStringBlocking_P(0, stringBuffer, 
										PSTR("\n\rBoot:\n\r"));

	setHeartRate(0);


	static dms4day_t startTime = 0;

	char count = '0';

	while(1)
	{
		tcnter_update();
		puat_update(0);

		if(dmsIsItTime(&startTime, 1*DMS_SEC))
				puat_sendByteBlocking(0, count);

		count++;
		if(count == '9'+1)
			count = '0';
		
		heartUpdate();


	}

	return 0;
}

