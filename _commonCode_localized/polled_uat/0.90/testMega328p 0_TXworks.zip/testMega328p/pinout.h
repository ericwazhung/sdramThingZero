#ifndef __PINOUT_H__
#define __PINOUT_H__

//Using the programming-header for debugging uart and heartbeat...
// These pins can be found on the device datasheet
// For newly-supported devices (e.g. atmega328p) they can also be found in
//  e.g. _commonCode[-local]/_make/atmega328p.mk
//
//
// 1  GND
// 2  V+
// 3  SCK    Rx0   (puar)
// 4  MOSI   Tx0   (puat)
// 5  /RST
// 6  MISO   Heart


//_PGM_xxx_yyy_NAME_ is a new method, a/o atmega328p.mk
// Most devices don't yet have it implemented, so must put actual pin/port
// names here (The commented pin/port names are from another device!)
//Likewise: If you decide to use different pins than those on the
// programming-header, type them here:
#define Rx0pin    _PGM_SCK_PIN_NAME_ //PA4      //SCK
#define Rx0PORT   _PGM_SCK_PORT_NAME_ //PORTA

//Making it more pin-compatible with sdramThing3.0...
#define Tx0pin		_PGM_MOSI_PIN_NAME_ //PA6		//MOSI
#define Tx0PORT	_PGM_MOSI_PORT_NAME_ //PORTA



#endif

