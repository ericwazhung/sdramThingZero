

extern __inline__ void puat_writeOutput(uint8_t puatNum, uint8_t value)
{    
	   printf("writeOutput[%d]: %d\n", puatNum, value);
}  

extern __inline__ void puat_initOutput(uint8_t puatNum)
{
	printf("puatInit\n");
}
