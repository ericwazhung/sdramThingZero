//Taken from polled_uat/test 0.10-5
//  Taken from stdinNonBlock
//  Taken from serIOtest20, and modified slightly

#include <stdio.h>
#include "../../../__std_wrappers/stdin_nonBlock/0.10/stdin_nonBlock.h"

#include <errno.h>
#include <string.h> //needed for strerror()
#include <fcntl.h> //file control for open/read
#include _POLLED_UAT_HEADER_


//These need to be global because they're used by polled_uat.c
// via #defines...
int lineVal = 1;
tcnter_source_t timerCounter = 0;

//These have been moved to the makefile
//#define PU_PC_DEBUG	1
//#define getbit(a) (lineVal)
//#define TCNT0	(timerCounter)
//#define OCR0A	(9)
//#define BIT_TCNT 6
//#include "../polled_uat.c"


#define handleError(string, exit) \
	if(errno)   \
{\
	   printf( string " Error %d: '%s'\n", errno, strerror(errno)); \
	   if(exit) \
	      return 1; \
	   else \
			errno = 0; \
}

//errno = 0 seems to work, whereas clearerr(stdin) doesn't


int main(void)
{

	int quit = 0;
	int timer = 0;

	stdinNB_init();

	printf("---Press q and press return to quit---\n");
	printf("   Press another letter and return to start sending.\n");
	printf("   (upper-case letters sent on puat 1, lower-case on 0).\n");

	//POLLED_UAT Specific Stuff
	uint8_t puat;

	for(puat=0; puat<NUMPUATS; puat++)
		puat_init(puat);


	while(!quit)
	{

		int kbChar = stdinNB_getChar();

		switch(kbChar)
			{
				case -1: //Nothing Received...
					break;
				case 'q':
					quit = 1;
					break;
				//POLLED_UAT TESTS:
				case '\n':
					break;
				//^^^ TO HERE
				default:
					//Send Upper-case chars to puat 1
					//     Lower-case to puat 0
					if((kbChar >= 'A') && (kbChar <= 'Z'))
						puat = 1;
					else
						puat = 0;

					if(puat_dataWaiting(puat))
						printf("Buffer[%d] Full; Ignoring '%c'\n", 
								(int)puat, kbChar);
					else
						puat_sendByte(puat,kbChar);
					//printf("Received: '%c'", kbChar);
			}


		for(puat=0; puat<NUMPUATS; puat++)
			puat_update(puat);


		//Run the loop 10 times a second, but update the tcnter only once per
		//second.
		usleep(100000);

		printf(".");
		timer++;

		if(timer == 10)
		{
			timerCounter++;
			if(timerCounter == TCNTER_SOURCE_OVERFLOW_VAL) //OCR0A)
				timerCounter = 0;
			timer=0;
			printf("TCNT: %d\n",timerCounter);
		}

	}


	return 0;
}

