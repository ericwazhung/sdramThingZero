#!/bin/bash

# Most of reallyCommon2.mk's bash-stuff is handled in that file,
# But it's probably a good idea to make these things shell-scripts, instead...
# (they're too hard to modify, too much confusion with $ vs $$, etc.)

# First Step: 'make delocalize'
#  will cause the project to work with the centralized _commonCode directory
#
# This script attempts to copy files from _commonCode_localized/ to the 
# centralized _commonCode/ if they don't already exist there.


#.PHONY: delocalize
#delocalize:
#	@/bin/rm -f $(LOCAL_MK)
#	@echo "### BEST NOT MODIFY THIS FILE, use 'make (de)localize' instead" 
# ...		> $(SHARED_MK)	
#	@echo "# When this is 1, we'll use the files in " 
#ifdef CENTRAL_COMDIR




CENTRAL_COMDIR="$1"
LOCAL_COM_DIR="$2"
CENTRAL_COMDIR_FULL="$3"

echo "### CHECKING whether local commonCode differs from central commonCode:"
echo " CENTRAL: '$CENTRAL_COMDIR' vs"
echo " LOCAL: '$LOCAL_COM_DIR'"


if [ ! -d "$CENTRAL_COMDIR" ]
then
   echo "*** The centralized commonCode directory does not exist:"
   echo "    Your makefile is set to "
   echo "    CENTRAL_COMDIR='$CENTRAL_COMDIR'"
   echo "                  ='$CENTRAL_COMDIR_FULL'"
   echo -n "    Would you like to create it? [y/n] "
   read yn
   if [ "$yn" == "y" ]
   then
      mkdir -p "$CENTRAL_COMDIR"
   else
      echo "*** Cannot delocalize without a centralized commonCode directory"
      echo "    Check the line 'CENTRAL_COMDIR=...' in your makefile"
      echo "    Or try again, and select 'y' when asked to create it."
      exit 1
   fi
fi

IFS="
"


unhandledCount=0
copyCount=0

diffOut="`diff -rq "$LOCAL_COM_DIR" "$CENTRAL_COMDIR"`"

for line in $diffOut 
do 
#	echo "diffOut: '$line'" 
   if [ "${line#"Only in $CENTRAL_COMDIR"}" != "$line" ]
   then
      # Don't handle files/dirs only in CENTRAL
      # (e.g. commonCode this project doesn't use)
      echo -n ""
   elif [ "${line#"Only in $LOCAL_COM_DIR"}" != "$line" ]
	then

      itemSubdir="${line##"Only in $LOCAL_COM_DIR"}"
      itemSubdir="${itemSubdir%%:*}"
      itemSubdir="${itemSubdir#/}"
      echo "itemSubdir='$itemSubdir'"


		copyCount=$((copyCount+1)) 
#		echo "$a: $line" 
      item="$LOCAL_COM_DIR/$itemSubdir/${line##*: }"
#      echo "   $item"

      toDir="$CENTRAL_COMDIR/$itemSubdir/$(basename "$item")"
      echo " Copying '$item'"
      echo "   to '$toDir'"
      cp -ri "$item" "$toDir"
      if [ "$?" != "0" ]
      then
         echo "   From: '$line'"
      fi
   else
      echo "NOT HANDLED: diffOut: '$line'"
      unhandledCount=$((unhandledCount+1))
   fi 
done 


if [[ $unhandledCount > 0 ]] 
then 
	echo "#########################################################" 
	echo "## Unhandled Differences found! Be sure to check them! ##" 
	echo "#########################################################" 
	echo -n "  Do you want to continue delocalizing? [y/n]"
   read yn
   if [ "$yn" == "y" ]
   then
      echo "continuing delocalization..."
      exit 0
   else
      exit 1
   fi
elif [[ $copyCount > 0 ]]
then
   echo "...Copyover complete."
else
   echo "...No differences found, nothing to do."
fi

echo "continuing delocalization..."
exit 0



