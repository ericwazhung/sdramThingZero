#!/bin/bash

# This is taken almost directly from kinsamanka at github.com:
#https://github.com/kinsamanka/PICnc-V2/wiki/OpenOCD-PIC32-Programmer

# His file was called pic32openocd

#TODO: I need to make sure to check his opensource licensing requests!


#TODO: Also need to look into making this device (not board) selectable...
#      e.g. via MCU...?
#      (currently I'm using a custom board.cfg)

#BRD_CFG=pic32mx150f128b.cfg

if [ -z $1 ]
then
  echo "firmware file is missing!"
  echo "Usage: $0 <hexfile>"
  exit
fi

#echo \$TRST_GPIO > /sys/class/gpio/unexport 2>/dev/null
#echo \$TRST_GPIO > /sys/class/gpio/export
#echo "low" > /sys/class/gpio/gpio\${TRST_GPIO}/direction
#echo  "1" > /sys/class/gpio/gpio\${TRST_GPIO}/active_low

#openocd  -f interface/rpi.cfg -f board/\${BRD_CFG} &

# Run openocd, but keep the script running... ('&')
openocd -f interface/ftdi/myFlyswatter.cfg -c "adapter_khz 4000" -f board/pic32_my2xx.cfg &

sleep 1

# Clever(?) piping... and nc instead of telnet...
(
echo 'reset init'
sleep 1
echo pic32mx unlock 0
sleep 1
echo reset init
echo program $1 reset exit
) | nc localhost 4444 > /dev/null

