//Pondering using a USB-to-Parallel adaptor 
//They seem to have three modes:
// One-directional
// EPP/ECP
// IEEE-1284

// One-directional likely won't work
//  (Would with an *internal* and bit-banging)
// IEEE-1284 looks a bit too complicated for my needs
//
// EPP/ECP looks to be the way to go...
//  Bidirectional, using the same 8-bit data lines
//  Strobe, etc...

//First we need to make sure it's *possible* to set it in EPP/ECP mode!
#include <stdio.h>
#include <sys/ioctl.h>
//#include <linux/drivers/usb/class/usblp.h>

//ALL THESE for open()?!
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <errno.h>
#include <string.h> //strerror

#if 0
#ifndef IOCNR_GET_PROTOCOLS
 #error "YEP"
#endif
#endif

int onError(char *location)
{
   if(errno)
   {
      printf("%s: Error %d, '%s\n", location, errno, strerror(errno));
      return 1;
   }
   else
      return 0;
}

int main(int argc, char* argv[])
{
   //ioctl requires a file-descriptor not a FILE*...
   // And we might want some of those other O_ options, as well.
   //FILE *printerPort;
   //printerPort = fopen("/dev/usb/lp0", "r+");

   int printerPort_FD =
      open("/dev/usb/lp0", O_RDWR); //Maybe O_NONBLOCK?
   
   if (printerPort_FD == -1)
   {
      if( onError("Open") )
         return 1;
      //printf("Open: Error %d, '%s'\n", errno, strerror(errno));
      //return 1;
   }



//These are defined in drivers/usb/class/usblp.c
// But there doesn't appear to be an associated header-file!
//This similar manual-entry (rather'n #including) is done in hpoj-0.91
#define IOCNR_GET_DEVICE_ID      1
#define IOCNR_GET_PROTOCOLS      2
#define IOCNR_SET_PROTOCOL    3
#define IOCNR_HP_SET_CHANNEL     4
#define IOCNR_GET_BUS_ADDRESS    5
#define IOCNR_GET_VID_PID     6
#define IOCNR_SOFT_RESET      7
   /* Get device_id string: */
#define LPIOC_GET_DEVICE_ID(len) _IOC(_IOC_READ, 'P', IOCNR_GET_DEVICE_ID, len)

/* The following ioctls were added for http://hpoj.sourceforge.net: */
/* Get two-int array:
  * [0]=current protocol (1=7/1/1, 2=7/1/2, 3=7/1/3),
  * [1]=supported protocol mask (mask&(1<<n)!=0 means 7/1/n supported): */

#define LPIOC_GET_PROTOCOLS(len) _IOC(_IOC_READ, 'P', IOCNR_GET_PROTOCOLS, len)

/* Set protocol (arg: 1=7/1/1, 2=7/1/2, 3=7/1/3): */
#define LPIOC_SET_PROTOCOL _IOC(_IOC_WRITE, 'P', IOCNR_SET_PROTOCOL, 0)

#define STRING_LEN  1000

   char ioctl_return[STRING_LEN] = { [0 ... (STRING_LEN-1)] = '\0'};
   
   ioctl(printerPort_FD, LPIOC_GET_DEVICE_ID(STRING_LEN), 
         (void*)ioctl_return);

   onError("DEVICE_ID");

   printf("DEVICE_ID: '%s'\n", ioctl_return);


   //Huh, isn't this architecture-dependent...?
   int twoInts[2];

   //WHOA DIGITY:
   //Major bug in hpoj...?
   //int twoints[2];
   //ioctl(llioInterface[EX_INTERFACE_MLC].fdDevice,LPIOC_GET_PROTOCOLS,
   //      &twoints) <---- twoints is already an address... &(twoints[0])!
   ioctl(printerPort_FD, LPIOC_GET_PROTOCOLS(sizeof(int[2])), 
         (void*)twoInts);

   onError("GET_PROTOCOLS");

   printf("Current Protocol: %d\n"
          "Supported Protocols (Mask): 0x%x\n", twoInts[0], twoInts[1]);
   

   if(argc > 1)
   {
      int newProto = atoi(argv[1]);
    
      printf("Per Request: Setting Protocol to %d\n", newProto); 

      ioctl(printerPort_FD, LPIOC_SET_PROTOCOL, (void*)(&newProto));

      onError("SET_PROTOCOL");
   }

   close(printerPort_FD);
}
