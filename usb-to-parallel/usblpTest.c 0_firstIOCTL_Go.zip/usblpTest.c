//Pondering using a USB-to-Parallel adaptor 
//They seem to have three modes:
// One-directional
// EPP/ECP
// IEEE-1284

// One-directional likely won't work
//  (Would with an *internal* and bit-banging)
// IEEE-1284 looks a bit too complicated for my needs
//
// EPP/ECP looks to be the way to go...
//  Bidirectional, using the same 8-bit data lines
//  Strobe, etc...

//First we need to make sure it's *possible* to set it in EPP/ECP mode!
#include <stdio.h>
#include <sys/ioctl.h>
//#include <linux/drivers/usb/class/usblp.h>

//ALL THESE for open()?!
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <errno.h>
#include <string.h> //strerror

#if 0
#ifndef IOCNR_GET_PROTOCOLS
 #error "YEP"
#endif
#endif


int main(void)
{
   //ioctl requires a file-descriptor not a FILE*...
   // And we might want some of those other O_ options, as well.
   //FILE *printerPort;
   //printerPort = fopen("/dev/usb/lp0", "r+");

   int printerPort_FD =
      open("/dev/usb/lp0", O_RDWR); //Maybe O_NONBLOCK?
   
   if (printerPort_FD == -1)
   {
      printf("Open: Error %d, '%s'\n", errno, strerror(errno));
      return 1;
   }

   char ioctl_return[80] = { [0 ... 79] = '\0'};


//These are defined in drivers/usb/class/usblp.c
// But there doesn't appear to be an associated header-file!
#define IOCNR_GET_DEVICE_ID      1
#define IOCNR_GET_PROTOCOLS      2
#define IOCNR_SET_PROTOCOL    3
#define IOCNR_HP_SET_CHANNEL     4
#define IOCNR_GET_BUS_ADDRESS    5
#define IOCNR_GET_VID_PID     6
#define IOCNR_SOFT_RESET      7
   /* Get device_id string: */
#define LPIOC_GET_DEVICE_ID(len) _IOC(_IOC_READ, 'P', IOCNR_GET_DEVICE_ID, len)


   ioctl(printerPort_FD, LPIOC_GET_DEVICE_ID(80), (void*)ioctl_return);

   printf("ioctl returned: '%s'\n", ioctl_return);

   close(printerPort_FD);
}
